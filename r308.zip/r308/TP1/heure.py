class Heure:
    """Représente une heure de la journée (h, m, s)."""
    
    def __init__(self, h: int, m: int, s: int):
        # TODO: Initialiser et valider les attributs
        self.h = h
        self.m = m
        self.s = s

    @classmethod
    def from_secondes(cls, total_secondes: int) -> "Heure":
        # TODO: Calculer h, m, s et retourner une nouvelle instance `cls(...)`
        heure = total_secondes//3600
        minute = total_secondes%3600//60
        seconde = total_secondes%60
        return cls(heure,minute,seconde)
    
    def __repr__(self) -> str:
        # TODO
        return f"{self.h} heure(s):{self.m} minute(s):{self.s} seconde(s)"

    def __str__(self) -> str:
        # TODO
        return f"{self.h} heure(s):{self.m} minute(s):{self.s} seconde(s)"

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Heure):
            return NotImplemented
        # TODO: Comparer self et other
        if other.h == self.h and other.m == self.m and other.s == self.s:
            return True
        return False

# --- Tests à valider ---
h1 = Heure(1, 1, 1)
print(f"repr(h1): {repr(h1)}")
print(f"str(h1): {str(h1)}")

# Test du classmethod
total_secs = 3661 # 1 heure, 1 minute, 1 seconde
h2 = Heure.from_secondes(total_secs)
assert h2.h == 1 and h2.m == 1 and h2.s == 1

# Test de l'égalité
h3 = Heure(1, 1, 1)
assert h1 == h2
assert h1 == h3
assert h2 != Heure(1, 1, 2)

print("Tests de l'exercice 4 passés avec succès !")