class Ticket:
    """Un ticket avec un identifiant unique auto-incrémenté."""
    
    # TODO: Créer un attribut de classe pour le compteur
    compteur = 0
    
    def __init__(self):
        # TODO: Assigner l'ID à l'instance et incrémenter le compteur
        self.id = Ticket.compteur
        Ticket.compteur += 1

    def __repr__(self) -> str:
        # TODO: Retourner la représentation du ticket
        return f"Le ticket : {self.id}"

# --- Tests à valider ---
ticket1 = Ticket()
ticket2 = Ticket()
ticket3 = Ticket()
ticket4 = Ticket()

print(ticket4)