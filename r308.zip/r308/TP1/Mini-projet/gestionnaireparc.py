import equipement as eqm

class GestionnaireParc:
    def __init__(self,nom_parc):
        self.nom = nom_parc
        self.equipement = []
    
    def ajouter_equipement(self,eqm):
        return self.equipement.append(eqm)
    
    def supprime(self):
        return self.equipement.pop()
    
    def __repr__(self):
        return f"GestionnaireParc('{self.nom}', equipements={self.equipement})"
    
    def rechercher_par_hostname(self,hostname):
        for elt in self.equipement:
            if elt.name == hostname:
                return elt
        return None

        
    def statistique(self):
        compteur = 0
        for e in self.equipement:
            if e.statut == "actif":
                compteur += 1
        return f" nombre total d'équipement {len(self.equipement)}, nombre total d'équipement actif ;{compteur}"
"""
g1=GestionnaireParc("Net1")
g1.ajouter_equipement(eqm.r1)
g1.ajouter_equipement(eqm.r2)
g1.ajouter_equipement(eqm.r3)

compte = g1.statistique()
print(g1)
print(compte)
"""
r1 = eqm.EquipementReseau("R1-Paris","192.168.1.1")
r2 = eqm.EquipementReseau("R2-Bruxelle","192.168.2.1")
r3= eqm.EquipementReseau("R3-Venise","192.168.3.1")


g1=GestionnaireParc("Net1")
g1.ajouter_equipement(r1)
g1.ajouter_equipement(r2)
g1.ajouter_equipement(r3)

r1.activer()
r3.activer()
r2.desactiver()

print(g1.rechercher_par_hostname("R2-Bruxelles"))
print(g1.statistique())