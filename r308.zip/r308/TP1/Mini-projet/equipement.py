class EquipementReseau:
    compteur_id = 0
    def __init__(self,hostname,ip_address):
        self.name = hostname
        self.addr = ip_address
        self.statut = "inactif"
        self.id = EquipementReseau.compteur_id
        EquipementReseau.compteur_id += 1
    
    def __repr__(self):
        return f"(Equipement_id:{self.id} | hostname :{self.name} | ip:{self.addr} | statut:{self.satut})"

    def activer(self):
        if self.statut == "inactif":
            self.statut = "actif"
            return self.statut
    
    def desactiver(self):
        if self.statut == "actif":
            self.statut = "inactif"
            return self.statut
        
    @property
    def est_actif(self):
        if self.statut == "actif":
            return True
        return False
    

if __name__=="__main__":
    r1 = EquipementReseau("R1-Paris","192.168.1.1")
    r2 = EquipementReseau("R2-Bruxelle","192.168.2.1")
    r3= EquipementReseau("R3-Venise","192.168.3.1")
    r1.activer()
    r3.activer()
    r2.desactiver()
    print(r1)
    print(r2)
    print(r3)

