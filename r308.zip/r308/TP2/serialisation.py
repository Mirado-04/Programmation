from __future__ import annotations
from datetime import date
import json, csv, pickle, os
import re
from typing import Iterable, List
from datex import Date
from errors import DateParseError

def date_from_record(record: str) -> Date:
    return Date(record["year"],record["month"],record["day"])

def date_to_record(d: Date) -> dict:
    return {"year": d._y, "month": d._m, "day": d._d}

def dump_dates_jsonl(dates: Iterable[Date], path: str) -> None:
    # TODO
    with open(path, "w", encoding="utf-8") as f:
        for d in dates:
            record = date_to_record(d)
            ligne = json.dumps(record)
            f.write(ligne + "\n")


def load_dates_jsonl(path: str) -> List[Date]:
    # TODO
    dates = []
    with open(path, "r", encoding="utf-8") as f:
        for ligne in f:
            record = json.loads(ligne)
            d = date_from_record(record)
            dates.append(d)
    return dates

def dump_dates_csv(dates: Iterable[Date], path: str) -> None:
    # TODO
    with open(path, "w", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["year","month","day"])
        for d in dates:
            record = date_to_record(d)
            writer.writerow([record["year"],record["month"],record["day"]])

def load_dates_csv(path: str) -> List[Date]:
    dates = []
    with open(path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for record in reader:
            d = Date(int(record["year"]), int(record["month"]), int(record["day"]))
            dates.append(d)
    return dates

def dump_dates_pickle(dates: Iterable[Date], path: str) -> None:
    # TODO
    with open(path, "wb") as f:
        pickle.dump(list(dates), f)

def load_dates_pickle(path: str) -> List[Date]:
    # TODO
    with open(path, "rb") as f:
        return pickle.load(f)

# --- Tests/bench ---
if __name__ == "__main__":
    # Générer des dates
    base = Date(2025, 1, 1)
    dates = [base.add_days(i) for i in range(10000)]

    dump_dates_jsonl(dates, "dates.jsonl")
    dump_dates_csv(dates, "dates.csv")
    dump_dates_pickle(dates, "dates.pkl")

    lj = load_dates_jsonl("dates.jsonl")
    lc = load_dates_csv("dates.csv")
    lp = load_dates_pickle("dates.pkl")

    assert lj[:3][0].to_iso() == "2025-01-01"
    assert lc[-1].to_iso() == "2052-05-18"  # 10000e jour
    assert lp[1234].to_iso() == dates[1234].to_iso()

    sizes = {p: os.path.getsize(p) for p in ["dates.jsonl","dates.csv","dates.pkl"]}
    print("Tailles (octets):", sizes)
    # Discussion attendue en compte-rendu: lisibilité vs compacité vs portabilité
