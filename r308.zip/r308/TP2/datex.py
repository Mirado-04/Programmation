from __future__ import annotations
from functools import total_ordering
import re
from typing import Tuple
from errors import InvalidDateError, DateParseError

# Vérifie si la date est bissextile et la longueur du mois
def est_bissextile(y):
    return y % 4 == 0 and (y % 100 != 0 or y % 400 == 0)

def jours_du_mois(y, m):
    # Precondition : 1 <= y <= 9999 et 1 <= m <= 12
    jours = [31, 28, 31, 30, 31, 30,
    31, 31, 30, 31, 30, 31]
    if m == 2 and est_bissextile(y):
        return 29
    return jours[m - 1]

@total_ordering
class Date:
    """Date grégorienne minimale, immuable en pratique (méthodes renvoient des copies)."""

    __slots__ = ("_y", "_m", "_d")

    def __init__(self, year: int, month: int, day: int):
        # TODO: valider et affecter _y, _m, _d ; lever InvalidDateError si invalide
        self._y = year
        self._m = month
        self._d = day
        if any(type(v) is not int for v in (year,month,day)):
            raise InvalidDateError("Entiers attendus")
        if not 1 <= year <= 9999:
            raise InvalidDateError("Annee hors limites")
        if not 1 <= month <= 12:
            raise InvalidDateError("Mois hors limites")
        if not 1 <= day <= jours_du_mois(year,month):
            raise InvalidDateError("Jour invalide")

        @property
        def year(self) -> int:
            return self._y
        @property
        def month(self) -> int:
            return self._m
        @property
        def day(self) -> int:
            return self._d

    def __repr__(self) -> str:
        # TODO: format non ambigu
        return f"Date({self._y},{self._m},{self._d})"

    def __str__(self) -> str:
        # TODO: format lisible YYYY-MM-DD
        return self.to_iso()

    def to_iso(self) -> str:
        # TODO
        return f"{self._y:04d}-{self._m:02d}-{self._d:02d}"

    @classmethod
    def from_iso(cls, s: str) -> "Date":
        # TODO: parser, lever DateParseError si invalide
        if not isinstance(s, str):
            raise DateParseError("Chaine attendue")
        if re.fullmatch(r"[0-9]{4}-[0-9]{2}-[0-9]{2}", s) is None:
            raise DateParseError("Format YYYY-MM-DD attendu")
        y, m, d = map(int, s.split("-"))
        try:
            return cls(y, m, d)
        except InvalidDateError as exc:
            raise DateParseError(f"Date invalide : {s}") from exc

    def is_leap_year(self) -> bool:
    # TODO
        return self._y % 4 == 0 and (self._y % 100 != 0 or self._y % 400 == 0)

    def _days_in_month(self, y: int, m: int) -> int:
    # TODO
        jours = [31, 28, 31, 30, 31, 30,31, 31, 30, 31, 30, 31]
        if m == 2 and est_bissextile(y):
            return 29
        return jours[m - 1]

    def day_of_year(self) -> int:
        return sum(self._days_in_month(self._y, m) for m in range(1, self._m)) + self._d

    def add_days(self, n: int) -> "Date":
        y, m, d = self._y, self._m, self._d + n

    # Si n est positif et qu'on dépasse le nombre de jours du mois courant
        while d > self._days_in_month(y, m):
            d -= self._days_in_month(y, m)
            m += 1
            if m > 12:
                m = 1
                y += 1

                # Si n est négatif et qu'on recule d'un ou plusieurs mois
        while d < 1:
            m -= 1
            if m < 1:
                m = 12
                y -= 1
                d += self._days_in_month(y, m)
        return Date(y, m, d)

    def __eq__(self, other):
        if not isinstance(other, Date):
            return NotImplemented
        return (self._y, self._m, self._d) == (other._y, other._m, other._d)
    def __lt__(self, other):
        if not isinstance(other, Date):
            return NotImplemented
        return (self._y, self._m, self._d) < (other._y, other._m, other._d)

# --- Tests rapides ---
if __name__ == "__main__":
    d = Date(2024, 2, 29)
    assert d.is_leap_year() is True
    assert str(d) == "2024-02-29"
    assert Date.from_iso("2025-09-22").to_iso() == "2025-09-22"

    try:
        Date(2023, 2, 29)
        assert False, "Devrait lever InvalidDateError"
    except InvalidDateError:
        pass

    try:
        Date.from_iso("2025-13-01")
        assert False, "Devrait lever DateParseError"
    except DateParseError:
        pass

    # add_days et ordre
    d1 = Date(2025, 12, 31).add_days(1)
    assert str(d1) == "2026-01-01"
    assert Date(2025, 1, 1) < Date(2025, 1, 2)

    print("Tests Ex1 OK")