from __future__ import annotations
from datex import Date, est_bissextile
from errors import InvalidDateError

class DateRange:
    __slots__ = ("start", "end")

    def __init__(self, start: Date, end: Date):
        # TODO: valider start &lt;= end
        if start > end:
            raise InvalidDateError("Start doit être inférieur ou égal à End")
        self.start = start
        self.end = end
        

    def duration(self) -> int:
        # TODO
        return (self.end.day_of_year() - self.start.day_of_year() + 1) + (self.end._y - self.start._y) * 365 + sum(1 for y in range(self.start._y, self.end._y) if est_bissextile(y))

    def contains(self, d: Date) -> bool:
        # TODO
        return self.start <= d <= self.end

    def overlaps(self, other: "DateRange") -> bool:
        # TODO
        return self.start <= other.end and other.start <= self.end

    def intersection(self, other: "DateRange") -> "DateRange | None":
        # TODO
        return DateRange(max(self.start, other.start), min(self.end, other.end)) if self.overlaps(other) else None

# --- Tests rapides ---
if __name__ == "__main__":
    a = DateRange(Date(2025, 9, 1), Date(2025, 9, 10))
    b = DateRange(Date(2025, 9, 5), Date(2025, 9, 15))
    c = a.intersection(b)
    assert c is not None and c.start.to_iso() == "2025-09-05" and c.end.to_iso() == "2025-09-10"
    assert a.duration() == 10
    assert a.contains(Date(2025, 9, 1)) and a.contains(Date(2025, 9, 10))
    print("Tests Ex2 OK")